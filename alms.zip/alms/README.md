# ALMS: A Unified Learning and Certification Platform (PHP + MySQL)

## Run it (XAMPP)
1. Copy this folder to `C:\xampp\htdocs\alms` (keep the folder name `alms`, or change `BASE_URL` in `config.php`).
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin, choose Import, and import `database.sql`.
4. Open http://localhost/alms/setup.php once to create the demo accounts, then delete `setup.php`.
5. Open http://localhost/alms/

Demo accounts (password `password123`): `student@alms.test`, `customer@alms.test`, `engineer@alms.test`

## What is included
| Feature | Files |
|---|---|
| 1. Registration | `register.php` |
| 2. Sign in + role-based access | `login.php`, `config.php` (`require_role`) |
| 3. Monitoring (CPU, memory, logs, feature flags) | `engineer/dashboard.php`, `logs.php`, `flags.php` |
| 4. CRUD tables | `engineer/courses.php`, `assignments.php`, `evaluations.php`, `users.php` |
| Student dashboard, deadlines, file upload (PDF/ZIP, 25 MB), confirmation email | `student/dashboard.php`, `submit.php` |
| Online payment and digital certificates | `customer/store.php`, `checkout.php`, `my_courses.php`, `certificate.php`, `verify.php` |

## Notes
- Payment is simulated in `customer/checkout.php` (see the marked block). For real PayMongo/Stripe, create a checkout session there and mark the payment paid only in a webhook.
- Confirmation emails use PHP `mail()`. On XAMPP configure `sendmail` or use PHPMailer; if mail fails, the submission is still saved and a warning is logged.
- Certificates open as a printable page: use Print > Save as PDF.
- Upload size: in `php.ini` set `upload_max_filesize = 25M` and `post_max_size = 30M`.
- Metrics use `sys_getloadavg()` and `/proc/meminfo` (Linux). On Windows, CPU shows 0 and memory is an estimate.
- Feature flags `registration_open`, `file_submission`, `online_payments`, `certificate_download` really switch those features on or off.
- "Completing" a certification course is a button in this demo; replace it with your own completion rule.
