<?php
// Printable certificate. Use the browser's Print > Save as PDF.
require __DIR__ . '/config.php';
require_role('customer');
if (!flag('certificate_download')) { flash('Certificate downloads are switched off right now.', 'err'); redirect('customer/my_courses.php'); }
$s = $pdo->prepare('SELECT ce.certificate_code, ce.issued_at, u.full_name, c.title
    FROM certificates ce JOIN enrollments en ON en.enrollment_id = ce.enrollment_id
    JOIN users u ON u.user_id = en.user_id JOIN courses c ON c.course_id = en.course_id
    WHERE ce.certificate_code = ? AND en.user_id = ?');
$s->execute([$_GET['code'] ?? '', current_user()['user_id']]);
$c = $s->fetch();
if (!$c) { http_response_code(404); die('Certificate not found.'); }
log_event('info', 'Certificate viewed: ' . $c['certificate_code']);
$title = 'Certificate'; include __DIR__ . '/includes/header.php';
?>
<p class="noprint"><button class="btn" onclick="window.print()">Print or save as PDF</button></p>
<div class="cert">
  <p>Universidad de Dagupan &middot; ALMS</p>
  <h1>Certificate of Completion</h1>
  <p>This certifies that</p>
  <div class="name"><?= e($c['full_name']) ?></div>
  <p>has successfully completed the certification course</p>
  <h2><?= e($c['title']) ?></h2>
  <p>Issued <?= e(date('F j, Y', strtotime($c['issued_at']))) ?></p>
  <p class="muted">Certificate code: <?= e($c['certificate_code']) ?><br>Verify at <?= e($_SERVER['HTTP_HOST'] . BASE_URL) ?>/verify.php</p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
