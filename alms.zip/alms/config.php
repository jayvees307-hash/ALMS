<?php
// ALMS configuration + shared helpers
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

define('DB_HOST', 'localhost');
define('DB_NAME', 'alms_db');
define('DB_USER', 'root');
define('DB_PASS', '');            // XAMPP default is empty
define('BASE_URL', '/alms');      // folder name inside htdocs
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_UPLOAD', 25 * 1024 * 1024); // 25 MB

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $ex) {
    die('Database connection failed. Check config.php and import database.sql.');
}

function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function redirect($path) { header('Location: ' . BASE_URL . '/' . ltrim($path, '/')); exit; }

function flash($msg, $type = 'ok') { $_SESSION['flash'] = [$msg, $type]; }

// CSRF
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field() { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
            http_response_code(419);
            die('Invalid form token. Go back and try again.');
        }
    }
}

// Auth + RBAC
function current_user() { return $_SESSION['user'] ?? null; }
function home_for($role) {
    return ['student' => 'student/dashboard.php',
            'customer' => 'customer/store.php',
            'software_engineer' => 'engineer/dashboard.php'][$role] ?? 'login.php';
}
function require_login() { if (!current_user()) redirect('login.php'); }
function require_role($roles) {
    require_login();
    if (!in_array(current_user()['role'], (array)$roles, true)) {
        http_response_code(403);
        die('403: your role is not allowed to open this page.');
    }
}

// System log + feature flags
function log_event($level, $message) {
    global $pdo;
    $uid = current_user()['user_id'] ?? null;
    $pdo->prepare('INSERT INTO system_logs (user_id, level, message) VALUES (?,?,?)')
        ->execute([$uid, $level, $message]);
}
function flag($name) {
    global $pdo;
    $s = $pdo->prepare('SELECT is_enabled FROM feature_flags WHERE flag_name = ?');
    $s->execute([$name]);
    $r = $s->fetch();
    return $r ? (bool)$r['is_enabled'] : false;
}

// Server metrics (CPU load and memory as percent)
function collect_metrics() {
    $cpu = 0.0; $mem = 0.0;
    if (function_exists('sys_getloadavg')) {
        $l = sys_getloadavg();
        $cores = 1;
        if (is_readable('/proc/cpuinfo')) $cores = max(1, substr_count(file_get_contents('/proc/cpuinfo'), 'processor'));
        $cpu = min(100, ($l[0] / $cores) * 100);
    }
    if (is_readable('/proc/meminfo')) {
        $m = file_get_contents('/proc/meminfo');
        if (preg_match('/MemTotal:\s+(\d+)/', $m, $t) && preg_match('/MemAvailable:\s+(\d+)/', $m, $a)) {
            $mem = (1 - $a[1] / $t[1]) * 100;
        }
    } else {
        $limit = (int)ini_get('memory_limit') > 0 ? (int)ini_get('memory_limit') * 1048576 : 134217728;
        $mem = min(100, memory_get_usage(true) / $limit * 100);
    }
    return [round($cpu, 2), round($mem, 2)];
}

function format_dt($s) { return $s ? date('M j, Y g:i A', strtotime($s)) : '-'; }
