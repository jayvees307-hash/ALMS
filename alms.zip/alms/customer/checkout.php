<?php
require __DIR__ . '/../config.php';
require_role('customer');
csrf_check();
$uid = current_user()['user_id'];
$cid = (int)($_GET['course_id'] ?? 0);
$s = $pdo->prepare("SELECT * FROM courses WHERE course_id = ? AND course_type = 'certification'");
$s->execute([$cid]); $c = $s->fetch();
if (!$c) { http_response_code(404); die('Course not found.'); }

$own = $pdo->prepare('SELECT 1 FROM enrollments WHERE user_id = ? AND course_id = ?');
$own->execute([$uid, $cid]);
if ($own->fetch()) { flash('You already own this course.'); redirect('customer/my_courses.php'); }

$enabled = flag('online_payments');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $enabled) {
    $gateway = in_array($_POST['gateway'] ?? '', ['paymongo', 'stripe'], true) ? $_POST['gateway'] : 'paymongo';
    $ref = strtoupper(substr($gateway, 0, 2)) . '-' . date('Ymd') . '-' . strtoupper(bin2hex(random_bytes(3)));
    $pdo->beginTransaction();
    try {
        $pdo->prepare("INSERT INTO payments (user_id, course_id, gateway, amount, status, reference_no) VALUES (?,?,?,?, 'pending', ?)")
            ->execute([$uid, $cid, $gateway, $c['price'], $ref]);
        $pid = $pdo->lastInsertId();

        // ---- DEMO GATEWAY -------------------------------------------------
        // In production, create a PayMongo/Stripe checkout session here, redirect the
        // customer to it, and mark the payment 'paid' only inside the gateway's webhook.
        // For this class demo the payment is confirmed immediately.
        $paid = true;
        // -------------------------------------------------------------------

        if ($paid) {
            $pdo->prepare("UPDATE payments SET status = 'paid', paid_at = NOW() WHERE payment_id = ?")->execute([$pid]);
            $pdo->prepare('INSERT INTO enrollments (user_id, course_id) VALUES (?,?)')->execute([$uid, $cid]);
        }
        $pdo->commit();
        log_event('info', "Payment $ref paid for course #$cid");
        flash('Payment received. Reference ' . $ref . '. The course is now in My certificates.');
        redirect('customer/my_courses.php');
    } catch (Throwable $ex) {
        $pdo->rollBack();
        log_event('error', 'Payment failed: ' . $ex->getMessage());
        flash('Payment could not be completed. Try again.', 'err');
        redirect('customer/checkout.php?course_id=' . $cid);
    }
}
$title = 'Checkout'; include __DIR__ . '/../includes/header.php';
?>
<h1>Checkout</h1>
<div class="card" style="max-width:520px">
  <strong><?= e($c['title']) ?></strong>
  <p class="stat">&#8369;<?= number_format($c['price'], 2) ?></p>
  <?php if (!$enabled): ?>
    <div class="flash err">Online payments are switched off right now. Try again later.</div>
  <?php else: ?>
  <form class="stack" method="post">
    <?= csrf_field() ?>
    <label>Pay with
      <select name="gateway"><option value="paymongo">PayMongo</option><option value="stripe">Stripe</option></select></label>
    <button class="btn">Pay &#8369;<?= number_format($c['price'], 2) ?></button>
    <p class="muted">Demo mode: the gateway step is simulated and the payment is confirmed immediately.</p>
  </form>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
