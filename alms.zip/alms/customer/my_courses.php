<?php
require __DIR__ . '/../config.php';
require_role('customer');
csrf_check();
$uid = current_user()['user_id'];

// Mark a course complete and issue the certificate
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete'])) {
    $eid = (int)$_POST['complete'];
    $s = $pdo->prepare("SELECT e.enrollment_id FROM enrollments e JOIN courses c ON c.course_id = e.course_id
        WHERE e.enrollment_id = ? AND e.user_id = ? AND e.status = 'active' AND c.course_type = 'certification'");
    $s->execute([$eid, $uid]);
    if ($s->fetch()) {
        $pdo->prepare("UPDATE enrollments SET status = 'completed', completed_at = NOW() WHERE enrollment_id = ?")->execute([$eid]);
        $code = 'ALMS-CERT-' . date('Y') . '-' . str_pad($eid, 4, '0', STR_PAD_LEFT);
        $pdo->prepare('INSERT IGNORE INTO certificates (enrollment_id, certificate_code, file_path) VALUES (?,?,?)')
            ->execute([$eid, $code, 'certificate.php?code=' . $code]);
        log_event('info', "Certificate $code issued");
        flash("Course completed. Certificate $code is ready.");
    }
    redirect('customer/my_courses.php');
}

$rows = $pdo->prepare("SELECT e.*, c.title, ce.certificate_code
    FROM enrollments e JOIN courses c ON c.course_id = e.course_id
    LEFT JOIN certificates ce ON ce.enrollment_id = e.enrollment_id
    WHERE e.user_id = ? AND c.course_type = 'certification' ORDER BY e.enrolled_at DESC");
$rows->execute([$uid]); $rows = $rows->fetchAll();

$pay = $pdo->prepare('SELECT p.*, c.title FROM payments p JOIN courses c ON c.course_id = p.course_id WHERE p.user_id = ? ORDER BY p.payment_id DESC');
$pay->execute([$uid]); $pay = $pay->fetchAll();

$title = 'My certificates'; include __DIR__ . '/../includes/header.php';
?>
<h1>My certification courses</h1>
<div class="scroll"><table>
<tr><th>Course</th><th>Enrolled</th><th>Status</th><th>Certificate</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
  <td><?= e($r['title']) ?></td>
  <td><?= e(format_dt($r['enrolled_at'])) ?></td>
  <td><span class="tag <?= $r['status'] === 'completed' ? 'ok' : '' ?>"><?= e($r['status']) ?></span></td>
  <td>
    <?php if ($r['certificate_code']): ?>
      <a class="btn small" href="<?= BASE_URL ?>/certificate.php?code=<?= e(urlencode($r['certificate_code'])) ?>">View / download</a>
      <div class="muted"><?= e($r['certificate_code']) ?></div>
    <?php else: ?>
      <form method="post" class="inline"><?= csrf_field() ?>
        <button class="btn small ghost" name="complete" value="<?= (int)$r['enrollment_id'] ?>">Mark as completed</button></form>
    <?php endif; ?>
  </td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="4">You have no courses yet. <a href="<?= BASE_URL ?>/customer/store.php">Browse the store</a>.</td></tr><?php endif; ?>
</table></div>

<h2>Payment history</h2>
<div class="scroll"><table>
<tr><th>Reference</th><th>Course</th><th>Gateway</th><th>Amount</th><th>Status</th><th>Paid</th></tr>
<?php foreach ($pay as $p): ?>
<tr><td><?= e($p['reference_no']) ?></td><td><?= e($p['title']) ?></td><td><?= e($p['gateway']) ?></td>
<td>&#8369;<?= number_format($p['amount'], 2) ?></td>
<td><span class="tag <?= $p['status'] === 'paid' ? 'ok' : ($p['status'] === 'failed' ? 'bad' : 'warn') ?>"><?= e($p['status']) ?></span></td>
<td><?= e(format_dt($p['paid_at'])) ?></td></tr>
<?php endforeach; ?>
<?php if (!$pay): ?><tr><td colspan="6">No payments yet.</td></tr><?php endif; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
