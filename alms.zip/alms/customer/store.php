<?php
require __DIR__ . '/../config.php';
require_role('customer');
$uid = current_user()['user_id'];
$courses = $pdo->prepare("SELECT c.*, (SELECT 1 FROM enrollments e WHERE e.course_id = c.course_id AND e.user_id = ?) AS owned
    FROM courses c WHERE c.course_type = 'certification' ORDER BY c.title");
$courses->execute([$uid]); $courses = $courses->fetchAll();
$title = 'Course store'; include __DIR__ . '/../includes/header.php';
?>
<h1>Certification courses</h1>
<div class="grid">
<?php foreach ($courses as $c): ?>
  <div class="card">
    <strong><?= e($c['title']) ?></strong>
    <p class="muted"><?= e($c['description']) ?></p>
    <details><summary>Syllabus</summary><p><?= nl2br(e(str_replace(' | ', "\n", $c['syllabus']))) ?></p></details>
    <p class="stat">&#8369;<?= number_format($c['price'], 2) ?></p>
    <?php if ($c['owned']): ?>
      <a class="btn ghost small" href="<?= BASE_URL ?>/customer/my_courses.php">Already enrolled</a>
    <?php else: ?>
      <a class="btn small" href="<?= BASE_URL ?>/customer/checkout.php?course_id=<?= (int)$c['course_id'] ?>">Buy course</a>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
<?php if (!$courses): ?><div class="card">No certification courses are on sale yet.</div><?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
