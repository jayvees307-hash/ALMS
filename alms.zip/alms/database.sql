-- ALMS: A Unified Learning and Certification Platform
-- Database schema (MySQL / MariaDB, works with XAMPP/phpMyAdmin)
-- Import this file in phpMyAdmin, then open /alms/setup.php once to create demo accounts.

CREATE DATABASE IF NOT EXISTS alms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alms_db;

DROP TABLE IF EXISTS server_metrics, system_logs, feature_flags, certificates,
  payments, evaluations, submissions, assignments, enrollments, courses, users;

CREATE TABLE users (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('student','customer','software_engineer') NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE courses (
  course_id   INT AUTO_INCREMENT PRIMARY KEY,
  title       VARCHAR(150) NOT NULL,
  description TEXT,
  course_type ENUM('academic','certification') NOT NULL,
  price       DECIMAL(10,2) DEFAULT 0.00,
  syllabus    TEXT
) ENGINE=InnoDB;

CREATE TABLE enrollments (
  enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  course_id     INT NOT NULL,
  status        ENUM('active','completed') NOT NULL DEFAULT 'active',
  enrolled_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  completed_at  TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY uq_user_course (user_id, course_id),
  FOREIGN KEY (user_id)   REFERENCES users(user_id)     ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE assignments (
  assignment_id INT AUTO_INCREMENT PRIMARY KEY,
  course_id     INT NOT NULL,
  title         VARCHAR(150) NOT NULL,
  instructions  TEXT,
  due_date      DATETIME NOT NULL,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE submissions (
  submission_id     INT AUTO_INCREMENT PRIMARY KEY,
  assignment_id     INT NOT NULL,
  user_id           INT NOT NULL,
  file_path         VARCHAR(255) NOT NULL,   -- PDF or ZIP, up to 25 MB
  original_name     VARCHAR(255) NOT NULL,
  submitted_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  confirmation_sent BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)       REFERENCES users(user_id)             ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE evaluations (
  evaluation_id INT AUTO_INCREMENT PRIMARY KEY,
  submission_id INT NOT NULL UNIQUE,
  score         DECIMAL(5,2) NOT NULL,
  remarks       TEXT,
  evaluated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (submission_id) REFERENCES submissions(submission_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE payments (
  payment_id   INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  course_id    INT NOT NULL,
  gateway      ENUM('stripe','paymongo') NOT NULL,
  amount       DECIMAL(10,2) NOT NULL,
  status       ENUM('pending','paid','failed') NOT NULL DEFAULT 'pending',
  reference_no VARCHAR(100) UNIQUE,
  paid_at      TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (user_id)   REFERENCES users(user_id)     ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE certificates (
  certificate_id   INT AUTO_INCREMENT PRIMARY KEY,
  enrollment_id    INT NOT NULL UNIQUE,
  certificate_code VARCHAR(50) NOT NULL UNIQUE,
  file_path        VARCHAR(255) NOT NULL,
  issued_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (enrollment_id) REFERENCES enrollments(enrollment_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE feature_flags (
  flag_id    INT AUTO_INCREMENT PRIMARY KEY,
  flag_name  VARCHAR(80) NOT NULL UNIQUE,
  is_enabled BOOLEAN DEFAULT FALSE,
  updated_by INT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (updated_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE system_logs (
  log_id     INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NULL,
  level      ENUM('info','warning','error') NOT NULL,
  message    TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE server_metrics (
  metric_id    INT AUTO_INCREMENT PRIMARY KEY,
  cpu_load     DECIMAL(5,2),   -- percent
  memory_usage DECIMAL(5,2),   -- percent
  recorded_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- Seed data (no user-dependent rows; setup.php adds demo users) ----------
INSERT INTO courses (title, description, course_type, price, syllabus) VALUES
('Software Engineering 1', 'Foundations of the software development life cycle.', 'academic', 0.00,
 'Week 1-3: Requirements | Week 4-6: Design | Week 7-9: Development | Week 10-12: Testing'),
('Introduction to Web Development', 'HTML, CSS, JavaScript and PHP basics.', 'certification', 1500.00,
 'Module 1: HTML/CSS | Module 2: JavaScript | Module 3: PHP and MySQL'),
('Data Privacy Essentials', 'Data Privacy Act of 2012 for everyday practice.', 'certification', 1200.00,
 'Module 1: RA 10173 overview | Module 2: Handling personal data | Module 3: Breach response');

INSERT INTO assignments (course_id, title, instructions, due_date) VALUES
(1, 'Software Requirements Specification', 'Submit your SRS as a PDF or ZIP.', DATE_ADD(NOW(), INTERVAL 7 DAY)),
(1, 'System Design Document', 'Include the ERD, DFD and use case diagram.', DATE_ADD(NOW(), INTERVAL 21 DAY));

INSERT INTO feature_flags (flag_name, is_enabled) VALUES
('registration_open', TRUE),
('file_submission', TRUE),
('online_payments', TRUE),
('certificate_download', TRUE);
