<?php
// CRUD: assignments
require __DIR__ . '/../config.php';
require_role('software_engineer');
csrf_check();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        $pdo->prepare('DELETE FROM assignments WHERE assignment_id = ?')->execute([(int)$_POST['delete']]);
        flash('Assignment deleted.');
    } else {
        $t = trim($_POST['title'] ?? ''); $cid = (int)($_POST['course_id'] ?? 0);
        $due = date('Y-m-d H:i:s', strtotime($_POST['due_date'] ?? ''));
        if ($t === '' || !$cid || empty($_POST['due_date'])) {
            flash('Enter a title, a course, and a due date.', 'err');
        } elseif (!empty($_POST['assignment_id'])) {
            $pdo->prepare('UPDATE assignments SET course_id=?, title=?, instructions=?, due_date=? WHERE assignment_id=?')
                ->execute([$cid, $t, $_POST['instructions'] ?? '', $due, (int)$_POST['assignment_id']]);
            flash('Assignment updated.');
        } else {
            $pdo->prepare('INSERT INTO assignments (course_id, title, instructions, due_date) VALUES (?,?,?,?)')
                ->execute([$cid, $t, $_POST['instructions'] ?? '', $due]);
            log_event('info', 'Assignment created: ' . $t);
            flash('Assignment added.');
        }
    }
    redirect('engineer/assignments.php');
}
$edit = null;
if (isset($_GET['edit'])) { $s = $pdo->prepare('SELECT * FROM assignments WHERE assignment_id = ?'); $s->execute([(int)$_GET['edit']]); $edit = $s->fetch(); }
$courses = $pdo->query("SELECT course_id, title FROM courses ORDER BY title")->fetchAll();
$rows = $pdo->query('SELECT a.*, c.title AS course_title FROM assignments a JOIN courses c ON c.course_id = a.course_id ORDER BY a.due_date')->fetchAll();
$title = 'Assignments'; include __DIR__ . '/../includes/header.php';
?>
<h1>Assignments</h1>
<div class="scroll"><table>
<tr><th>Title</th><th>Course</th><th>Due</th><th></th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['title']) ?></td><td><?= e($r['course_title']) ?></td><td><?= e(format_dt($r['due_date'])) ?></td>
<td><a class="btn small ghost" href="?edit=<?= (int)$r['assignment_id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Delete this assignment and its submissions?')"><?= csrf_field() ?>
<button class="btn small danger" name="delete" value="<?= (int)$r['assignment_id'] ?>">Delete</button></form></td></tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="4">No assignments yet.</td></tr><?php endif; ?>
</table></div>

<h2><?= $edit ? 'Edit assignment' : 'Add assignment' ?></h2>
<form class="stack card" method="post"><?= csrf_field() ?>
  <?php if ($edit): ?><input type="hidden" name="assignment_id" value="<?= (int)$edit['assignment_id'] ?>"><?php endif; ?>
  <label>Course <select name="course_id">
    <?php foreach ($courses as $c): ?><option value="<?= (int)$c['course_id'] ?>" <?= ($edit['course_id'] ?? 0) == $c['course_id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option><?php endforeach; ?></select></label>
  <label>Title <input name="title" required maxlength="150" value="<?= e($edit['title'] ?? '') ?>"></label>
  <label>Instructions <textarea name="instructions" rows="3"><?= e($edit['instructions'] ?? '') ?></textarea></label>
  <label>Due date <input type="datetime-local" name="due_date" required value="<?= $edit ? e(date('Y-m-d\TH:i', strtotime($edit['due_date']))) : '' ?>"></label>
  <div><button class="btn"><?= $edit ? 'Save changes' : 'Add assignment' ?></button><?php if ($edit): ?> <a href="assignments.php">Cancel</a><?php endif; ?></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
