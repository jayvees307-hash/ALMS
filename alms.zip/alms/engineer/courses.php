<?php
// CRUD: courses (Create, Read, Update, Delete)
require __DIR__ . '/../config.php';
require_role('software_engineer');
csrf_check();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {                                   // DELETE
        $pdo->prepare('DELETE FROM courses WHERE course_id = ?')->execute([(int)$_POST['delete']]);
        log_event('info', 'Course #' . (int)$_POST['delete'] . ' deleted');
        flash('Course deleted.');
    } else {
        $t = trim($_POST['title'] ?? ''); $type = $_POST['course_type'] ?? '';
        $price = (float)($_POST['price'] ?? 0);
        if ($t === '' || !in_array($type, ['academic', 'certification'], true) || $price < 0) {
            flash('Enter a title, a type, and a price of 0 or more.', 'err');
        } elseif (!empty($_POST['course_id'])) {                     // UPDATE
            $pdo->prepare('UPDATE courses SET title=?, description=?, course_type=?, price=?, syllabus=? WHERE course_id=?')
                ->execute([$t, $_POST['description'] ?? '', $type, $price, $_POST['syllabus'] ?? '', (int)$_POST['course_id']]);
            log_event('info', 'Course #' . (int)$_POST['course_id'] . ' updated');
            flash('Course updated.');
        } else {                                                     // CREATE
            $pdo->prepare('INSERT INTO courses (title, description, course_type, price, syllabus) VALUES (?,?,?,?,?)')
                ->execute([$t, $_POST['description'] ?? '', $type, $price, $_POST['syllabus'] ?? '']);
            log_event('info', 'Course created: ' . $t);
            flash('Course added.');
        }
    }
    redirect('engineer/courses.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $s = $pdo->prepare('SELECT * FROM courses WHERE course_id = ?'); $s->execute([(int)$_GET['edit']]); $edit = $s->fetch();
}
$rows = $pdo->query('SELECT * FROM courses ORDER BY course_id DESC')->fetchAll();   // READ
$title = 'Courses'; include __DIR__ . '/../includes/header.php';
?>
<h1>Courses</h1>
<div class="scroll"><table>
<tr><th>ID</th><th>Title</th><th>Type</th><th>Price</th><th></th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= (int)$r['course_id'] ?></td><td><?= e($r['title']) ?></td><td><?= e($r['course_type']) ?></td>
<td>&#8369;<?= number_format($r['price'], 2) ?></td>
<td><a class="btn small ghost" href="?edit=<?= (int)$r['course_id'] ?>">Edit</a>
<form method="post" class="inline" onsubmit="return confirm('Delete this course and its enrollments and assignments?')"><?= csrf_field() ?>
<button class="btn small danger" name="delete" value="<?= (int)$r['course_id'] ?>">Delete</button></form></td></tr>
<?php endforeach; ?>
</table></div>

<h2><?= $edit ? 'Edit course #' . (int)$edit['course_id'] : 'Add course' ?></h2>
<form class="stack card" method="post"><?= csrf_field() ?>
  <?php if ($edit): ?><input type="hidden" name="course_id" value="<?= (int)$edit['course_id'] ?>"><?php endif; ?>
  <label>Title <input name="title" required maxlength="150" value="<?= e($edit['title'] ?? '') ?>"></label>
  <label>Type <select name="course_type">
    <?php foreach (['academic', 'certification'] as $t): ?><option <?= ($edit['course_type'] ?? '') === $t ? 'selected' : '' ?>><?= $t ?></option><?php endforeach; ?></select></label>
  <label>Price (PHP, 0 for academic) <input type="number" step="0.01" min="0" name="price" value="<?= e($edit['price'] ?? '0.00') ?>"></label>
  <label>Description <textarea name="description" rows="2"><?= e($edit['description'] ?? '') ?></textarea></label>
  <label>Syllabus <textarea name="syllabus" rows="3"><?= e($edit['syllabus'] ?? '') ?></textarea></label>
  <div><button class="btn"><?= $edit ? 'Save changes' : 'Add course' ?></button>
  <?php if ($edit): ?> <a href="courses.php">Cancel</a><?php endif; ?></div>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
