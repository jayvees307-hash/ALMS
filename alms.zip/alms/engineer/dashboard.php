<?php
require __DIR__ . '/../config.php';
require_role('software_engineer');

[$cpu, $mem] = collect_metrics();
$pdo->prepare('INSERT INTO server_metrics (cpu_load, memory_usage) VALUES (?,?)')->execute([$cpu, $mem]);
$pdo->exec('DELETE FROM server_metrics WHERE metric_id < (SELECT m FROM (SELECT MAX(metric_id) - 500 AS m FROM server_metrics) t)');

$recent = $pdo->query('SELECT * FROM server_metrics ORDER BY metric_id DESC LIMIT 15')->fetchAll();
$count = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
$stats = [
    'Users' => $count('SELECT COUNT(*) FROM users'),
    'Courses' => $count('SELECT COUNT(*) FROM courses'),
    'Submissions' => $count('SELECT COUNT(*) FROM submissions'),
    'Paid payments' => $count("SELECT COUNT(*) FROM payments WHERE status = 'paid'"),
    'Certificates issued' => $count('SELECT COUNT(*) FROM certificates'),
    'Errors (24h)' => $count("SELECT COUNT(*) FROM system_logs WHERE level = 'error' AND created_at > NOW() - INTERVAL 1 DAY"),
];
$errs = $pdo->query("SELECT * FROM system_logs WHERE level IN ('error','warning') ORDER BY log_id DESC LIMIT 5")->fetchAll();
$title = 'Monitoring'; include __DIR__ . '/../includes/header.php';
?>
<h1>System monitoring</h1>
<div class="grid">
  <div class="card"><div class="muted">CPU load</div><div class="stat"><?= e($cpu) ?>%</div>
    <div class="bar"><i style="width:<?= min(100, (float)$cpu) ?>%"></i></div></div>
  <div class="card"><div class="muted">Memory usage</div><div class="stat"><?= e($mem) ?>%</div>
    <div class="bar"><i style="width:<?= min(100, (float)$mem) ?>%"></i></div></div>
  <?php foreach ($stats as $k => $v): ?>
    <div class="card"><div class="muted"><?= e($k) ?></div><div class="stat"><?= (int)$v ?></div></div>
  <?php endforeach; ?>
</div>
<p class="muted">Each time this page loads, one reading is saved. <a href="">Take a new reading</a></p>

<h2>Recent readings</h2>
<div class="scroll"><table>
<tr><th>Time</th><th>CPU %</th><th>Memory %</th></tr>
<?php foreach ($recent as $m): ?>
<tr><td><?= e(format_dt($m['recorded_at'])) ?></td><td><?= e($m['cpu_load']) ?></td><td><?= e($m['memory_usage']) ?></td></tr>
<?php endforeach; ?>
</table></div>

<h2>Latest warnings and errors</h2>
<div class="scroll"><table>
<tr><th>Time</th><th>Level</th><th>Message</th></tr>
<?php foreach ($errs as $l): ?>
<tr><td><?= e(format_dt($l['created_at'])) ?></td><td><span class="tag <?= $l['level'] === 'error' ? 'bad' : 'warn' ?>"><?= e($l['level']) ?></span></td><td><?= e($l['message']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$errs): ?><tr><td colspan="3">Nothing to report.</td></tr><?php endif; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
