<?php
require __DIR__ . '/../config.php';
require_role('software_engineer');
$s = $pdo->prepare('SELECT file_path, original_name FROM submissions WHERE submission_id = ?');
$s->execute([(int)($_GET['id'] ?? 0)]); $r = $s->fetch();
$path = $r ? UPLOAD_DIR . basename($r['file_path']) : '';
if (!$r || !is_file($path)) { http_response_code(404); die('File not found.'); }
$ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
header('Content-Type: ' . ($ext === 'pdf' ? 'application/pdf' : 'application/zip'));
header('Content-Disposition: attachment; filename="' . str_replace('"', '', basename($r['original_name'])) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
