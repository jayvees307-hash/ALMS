<?php
// Record and update evaluation scores for submissions
require __DIR__ . '/../config.php';
require_role('software_engineer');
csrf_check();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove'])) {
    $pdo->prepare('DELETE FROM evaluations WHERE evaluation_id = ?')->execute([(int)$_POST['remove']]);
    flash('Evaluation removed.'); redirect('engineer/evaluations.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sid = (int)($_POST['submission_id'] ?? 0); $score = $_POST['score'] ?? '';
    if ($sid && is_numeric($score) && $score >= 0 && $score <= 100) {
        $pdo->prepare('INSERT INTO evaluations (submission_id, score, remarks) VALUES (?,?,?)
            ON DUPLICATE KEY UPDATE score = VALUES(score), remarks = VALUES(remarks), evaluated_at = NOW()')
            ->execute([$sid, $score, trim($_POST['remarks'] ?? '')]);
        log_event('info', "Submission #$sid evaluated");
        flash('Evaluation saved.');
    } else flash('Enter a score from 0 to 100.', 'err');
    redirect('engineer/evaluations.php');
}
$rows = $pdo->query('SELECT s.*, a.title AS atitle, u.full_name, ev.evaluation_id, ev.score, ev.remarks
    FROM submissions s JOIN assignments a ON a.assignment_id = s.assignment_id
    JOIN users u ON u.user_id = s.user_id LEFT JOIN evaluations ev ON ev.submission_id = s.submission_id
    ORDER BY s.submitted_at DESC')->fetchAll();
$title = 'Evaluations'; include __DIR__ . '/../includes/header.php';
?>
<h1>Evaluations</h1>
<div class="scroll"><table>
<tr><th>Student</th><th>Assignment</th><th>Submitted</th><th>File</th><th>Score and remarks</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
  <td><?= e($r['full_name']) ?></td><td><?= e($r['atitle']) ?></td><td><?= e(format_dt($r['submitted_at'])) ?></td>
  <td><a href="<?= BASE_URL ?>/engineer/download.php?id=<?= (int)$r['submission_id'] ?>"><?= e($r['original_name']) ?></a></td>
  <td><form method="post" style="display:grid;gap:.4rem;min-width:230px"><?= csrf_field() ?>
    <input type="hidden" name="submission_id" value="<?= (int)$r['submission_id'] ?>">
    <input type="number" name="score" min="0" max="100" step="0.01" placeholder="Score (0-100)" required value="<?= e($r['score'] ?? '') ?>">
    <input name="remarks" placeholder="Remarks" value="<?= e($r['remarks'] ?? '') ?>">
    <span><button class="btn small"><?= $r['evaluation_id'] ? 'Update' : 'Save' ?></button>
    <?php if ($r['evaluation_id']): ?> <button class="btn small danger" name="remove" value="<?= (int)$r['evaluation_id'] ?>" formnovalidate onclick="return confirm('Remove this evaluation?')">Remove</button><?php endif; ?></span>
  </form></td>
</tr>
<?php endforeach; ?>
<?php if (!$rows): ?><tr><td colspan="5">No submissions yet.</td></tr><?php endif; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
