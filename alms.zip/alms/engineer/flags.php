<?php
require __DIR__ . '/../config.php';
require_role('software_engineer');
csrf_check();
$uid = current_user()['user_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['toggle'])) {
        $pdo->prepare('UPDATE feature_flags SET is_enabled = NOT is_enabled, updated_by = ? WHERE flag_id = ?')->execute([$uid, (int)$_POST['toggle']]);
        log_event('info', 'Feature flag #' . (int)$_POST['toggle'] . ' toggled');
        flash('Flag updated. It takes effect immediately, with no restart.');
    } elseif (isset($_POST['add'])) {
        $n = strtolower(trim($_POST['flag_name'] ?? ''));
        if (preg_match('/^[a-z0-9_]{2,80}$/', $n)) {
            $pdo->prepare('INSERT IGNORE INTO feature_flags (flag_name, is_enabled, updated_by) VALUES (?,0,?)')->execute([$n, $uid]);
            flash('Flag added (off by default).');
        } else flash('Use 2-80 lowercase letters, digits or underscores.', 'err');
    } elseif (isset($_POST['delete'])) {
        $pdo->prepare('DELETE FROM feature_flags WHERE flag_id = ?')->execute([(int)$_POST['delete']]);
        flash('Flag deleted.');
    }
    redirect('engineer/flags.php');
}
$flags = $pdo->query('SELECT f.*, u.email FROM feature_flags f LEFT JOIN users u ON u.user_id = f.updated_by ORDER BY flag_name')->fetchAll();
$title = 'Feature flags'; include __DIR__ . '/../includes/header.php';
?>
<h1>Feature flags</h1>
<div class="scroll"><table>
<tr><th>Flag</th><th>State</th><th>Last changed by</th><th>Updated</th><th></th></tr>
<?php foreach ($flags as $f): ?>
<tr><td><code><?= e($f['flag_name']) ?></code></td>
<td><span class="tag <?= $f['is_enabled'] ? 'ok' : 'bad' ?>"><?= $f['is_enabled'] ? 'On' : 'Off' ?></span></td>
<td><?= e($f['email'] ?? '-') ?></td><td><?= e(format_dt($f['updated_at'])) ?></td>
<td>
  <form method="post" class="inline"><?= csrf_field() ?><button class="btn small" name="toggle" value="<?= (int)$f['flag_id'] ?>"><?= $f['is_enabled'] ? 'Turn off' : 'Turn on' ?></button></form>
  <form method="post" class="inline" onsubmit="return confirm('Delete this flag?')"><?= csrf_field() ?><button class="btn small danger" name="delete" value="<?= (int)$f['flag_id'] ?>">Delete</button></form>
</td></tr>
<?php endforeach; ?>
</table></div>
<h2>Add a flag</h2>
<form class="stack card" method="post"><?= csrf_field() ?>
  <label>Flag name <input name="flag_name" placeholder="new_feature" required></label>
  <button class="btn" name="add" value="1">Add flag</button>
</form>
<p class="muted">Built-in flags used by the app: registration_open, file_submission, online_payments, certificate_download.</p>
<?php include __DIR__ . '/../includes/footer.php'; ?>
