<?php
require __DIR__ . '/../config.php';
require_role('software_engineer');
$q = trim($_GET['q'] ?? ''); $lvl = $_GET['level'] ?? '';
$sql = 'SELECT l.*, u.email FROM system_logs l LEFT JOIN users u ON u.user_id = l.user_id WHERE 1=1';
$args = [];
if ($q !== '') { $sql .= ' AND (l.message LIKE ? OR u.email LIKE ?)'; $args[] = "%$q%"; $args[] = "%$q%"; }
if (in_array($lvl, ['info', 'warning', 'error'], true)) { $sql .= ' AND l.level = ?'; $args[] = $lvl; }
$sql .= ' ORDER BY l.log_id DESC LIMIT 200';
$s = $pdo->prepare($sql); $s->execute($args); $logs = $s->fetchAll();
$title = 'Logs'; include __DIR__ . '/../includes/header.php';
?>
<h1>System logs</h1>
<form method="get" class="card" style="display:flex;gap:.7rem;flex-wrap:wrap;align-items:end">
  <label style="flex:1;min-width:200px">Search message or user <input name="q" value="<?= e($q) ?>"></label>
  <label>Level <select name="level"><option value="">All</option>
    <?php foreach (['info', 'warning', 'error'] as $l): ?><option <?= $lvl === $l ? 'selected' : '' ?>><?= $l ?></option><?php endforeach; ?></select></label>
  <button class="btn">Search</button>
</form>
<p class="muted">Showing up to 200 newest entries (<?= count($logs) ?> found).</p>
<div class="scroll"><table>
<tr><th>Time</th><th>Level</th><th>User</th><th>Message</th></tr>
<?php foreach ($logs as $l): ?>
<tr><td><?= e(format_dt($l['created_at'])) ?></td>
<td><span class="tag <?= ['error' => 'bad', 'warning' => 'warn', 'info' => ''][$l['level']] ?>"><?= e($l['level']) ?></span></td>
<td><?= e($l['email'] ?? '-') ?></td><td><?= e($l['message']) ?></td></tr>
<?php endforeach; ?>
<?php if (!$logs): ?><tr><td colspan="4">No log entries match.</td></tr><?php endif; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
