<?php
// Users: list, change role, delete
require __DIR__ . '/../config.php';
require_role('software_engineer');
csrf_check();
$me = current_user()['user_id'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['user_id'] ?? 0);
    if ($id === $me) {
        flash('You cannot change or delete your own account here.', 'err');
    } elseif (isset($_POST['delete'])) {
        $pdo->prepare('DELETE FROM users WHERE user_id = ?')->execute([$id]);
        log_event('warning', "User #$id deleted");
        flash('User deleted.');
    } elseif (in_array($_POST['role'] ?? '', ['student', 'customer', 'software_engineer'], true)) {
        $pdo->prepare('UPDATE users SET role = ? WHERE user_id = ?')->execute([$_POST['role'], $id]);
        log_event('warning', "User #$id role changed to " . $_POST['role']);
        flash('Role updated.');
    }
    redirect('engineer/users.php');
}
$rows = $pdo->query('SELECT * FROM users ORDER BY user_id')->fetchAll();
$title = 'Users'; include __DIR__ . '/../includes/header.php';
?>
<h1>Users</h1>
<div class="scroll"><table>
<tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th></th></tr>
<?php foreach ($rows as $r): ?>
<tr><td><?= e($r['full_name']) ?></td><td><?= e($r['email']) ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>">
  <select name="role" onchange="this.form.submit()" style="width:auto">
  <?php foreach (['student', 'customer', 'software_engineer'] as $ro): ?><option <?= $r['role'] === $ro ? 'selected' : '' ?>><?= $ro ?></option><?php endforeach; ?></select></form></td>
<td><?= e(format_dt($r['created_at'])) ?></td>
<td><?php if ((int)$r['user_id'] !== $me): ?>
<form method="post" class="inline" onsubmit="return confirm('Delete this user and all their records?')"><?= csrf_field() ?>
<input type="hidden" name="user_id" value="<?= (int)$r['user_id'] ?>"><button class="btn small danger" name="delete" value="1">Delete</button></form>
<?php endif; ?></td></tr>
<?php endforeach; ?>
</table></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
