</main>
<footer>ALMS: A Unified Learning and Certification Platform &middot; Universidad de Dagupan</footer>
</body></html>
