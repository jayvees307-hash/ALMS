<?php
// Usage: $title = 'Page'; include header.php
$u = current_user();
$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$role = $u['role'] ?? null;
$links = [];
if ($role === 'student') $links = ['student/dashboard.php' => 'My courses'];
if ($role === 'customer') $links = ['customer/store.php' => 'Course store', 'customer/my_courses.php' => 'My certificates'];
if ($role === 'software_engineer') $links = [
    'engineer/dashboard.php' => 'Monitoring', 'engineer/logs.php' => 'Logs', 'engineer/flags.php' => 'Feature flags',
    'engineer/courses.php' => 'Courses', 'engineer/assignments.php' => 'Assignments',
    'engineer/evaluations.php' => 'Evaluations', 'engineer/users.php' => 'Users'];
?><!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'ALMS') ?> | ALMS</title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/style.css">
</head><body>
<header class="top">
  <a class="brand" href="<?= BASE_URL ?>/index.php">ALMS</a>
  <nav>
    <?php foreach ($links as $href => $label): ?>
      <a href="<?= BASE_URL . '/' . $href ?>"><?= e($label) ?></a>
    <?php endforeach; ?>
    <a href="<?= BASE_URL ?>/verify.php">Verify certificate</a>
  </nav>
  <div class="who">
    <?php if ($u): ?>
      <span><?= e($u['full_name']) ?> (<?= e(str_replace('_', ' ', $u['role'])) ?>)</span>
      <a class="btn small ghost" href="<?= BASE_URL ?>/logout.php">Sign out</a>
    <?php else: ?>
      <a class="btn small ghost" href="<?= BASE_URL ?>/login.php">Sign in</a>
      <a class="btn small" href="<?= BASE_URL ?>/register.php">Register</a>
    <?php endif; ?>
  </div>
</header>
<main>
<?php if ($flash): ?><div class="flash <?= e($flash[1]) ?>"><?= e($flash[0]) ?></div><?php endif; ?>
