<?php
require __DIR__ . '/config.php';
if (current_user()) redirect(home_for(current_user()['role']));
$title = 'Welcome'; include __DIR__ . '/includes/header.php';
?>
<div class="card">
  <h1>One platform for coursework, certification, and system operations</h1>
  <p>Students track deadlines and submit assignments. Customers buy short certification courses and download certificates. Software engineers monitor the server and control features.</p>
  <p><a class="btn" href="<?= BASE_URL ?>/register.php">Create an account</a> <a class="btn ghost" href="<?= BASE_URL ?>/login.php">Sign in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
