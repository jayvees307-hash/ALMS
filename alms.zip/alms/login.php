<?php
require __DIR__ . '/config.php';
csrf_check();
if (current_user()) redirect(home_for(current_user()['role']));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $s = $pdo->prepare('SELECT * FROM users WHERE email = ?'); $s->execute([$email]);
    $u = $s->fetch();
    if ($u && password_verify($_POST['password'] ?? '', $u['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['user_id' => (int)$u['user_id'], 'full_name' => $u['full_name'], 'email' => $u['email'], 'role' => $u['role']];
        log_event('info', 'Signed in: ' . $u['email']);
        redirect(home_for($u['role']));
    }
    $error = 'Email or password is incorrect.';
    log_event('warning', 'Failed sign-in for: ' . $email);
}
$title = 'Sign in'; include __DIR__ . '/includes/header.php';
?>
<div class="auth card">
  <h1>Sign in</h1>
  <?php if ($error): ?><div class="flash err"><?= e($error) ?></div><?php endif; ?>
  <form class="stack" method="post">
    <?= csrf_field() ?>
    <label>Email <input type="email" name="email" required autofocus></label>
    <label>Password <input type="password" name="password" required></label>
    <button class="btn">Sign in</button>
  </form>
  <p class="muted">No account? <a href="<?= BASE_URL ?>/register.php">Register</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
