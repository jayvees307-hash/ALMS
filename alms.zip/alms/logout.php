<?php
require __DIR__ . '/config.php';
if (current_user()) log_event('info', 'Signed out: ' . current_user()['email']);
$_SESSION = []; session_destroy();
session_start(); flash('You have been signed out.');
redirect('login.php');
