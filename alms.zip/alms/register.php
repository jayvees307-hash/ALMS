<?php
require __DIR__ . '/config.php';
csrf_check();
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!flag('registration_open')) {
        $errors[] = 'Registration is closed right now.';
    } else {
        $name = trim($_POST['full_name'] ?? '');
        $email = strtolower(trim($_POST['email'] ?? ''));
        $pass = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? '';
        if ($name === '' || strlen($name) > 100) $errors[] = 'Enter your full name (up to 100 characters).';
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
        if (strlen($pass) < 8) $errors[] = 'Password must have at least 8 characters.';
        if (!in_array($role, ['student', 'customer'], true)) $errors[] = 'Choose Student or Customer.';
        if (empty($_POST['consent'])) $errors[] = 'You must agree to the data privacy notice.';
        if (!$errors) {
            $s = $pdo->prepare('SELECT 1 FROM users WHERE email = ?'); $s->execute([$email]);
            if ($s->fetch()) {
                $errors[] = 'That email is already registered.';
            } else {
                $pdo->prepare('INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)')
                    ->execute([$name, $email, password_hash($pass, PASSWORD_DEFAULT), $role]);
                log_event('info', "New $role registered: $email");
                flash('Account created. You can sign in now.');
                redirect('login.php');
            }
        }
    }
}
$title = 'Register'; include __DIR__ . '/includes/header.php';
?>
<div class="auth card">
  <h1>Create account</h1>
  <?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
  <form class="stack" method="post">
    <?= csrf_field() ?>
    <label>Full name <input name="full_name" required maxlength="100" value="<?= e($_POST['full_name'] ?? '') ?>"></label>
    <label>Email <input type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>"></label>
    <label>Password (8+ characters) <input type="password" name="password" required minlength="8"></label>
    <label>I am a
      <select name="role">
        <option value="student">Student (coursework and assignments)</option>
        <option value="customer">Customer (certification courses)</option>
      </select></label>
    <label style="display:flex;gap:.5rem;font-weight:400"><input type="checkbox" name="consent" style="width:auto"> I agree that ALMS may store my account data as described under the Data Privacy Act of 2012 (RA 10173).</label>
    <button class="btn">Register</button>
  </form>
  <p class="muted">Already registered? <a href="<?= BASE_URL ?>/login.php">Sign in</a></p>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
