<?php
// Run ONCE after importing database.sql, then DELETE this file.
require __DIR__ . '/config.php';
$n = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
if ($n > 0) die('Setup already done. Delete setup.php.');
$demo = [
    ['Juan Dela Cruz',  'student@alms.test',  'student'],
    ['Maria Santos',    'customer@alms.test', 'customer'],
    ['Paolo Reyes',     'engineer@alms.test', 'software_engineer'],
];
$ins = $pdo->prepare('INSERT INTO users (full_name,email,password_hash,role) VALUES (?,?,?,?)');
foreach ($demo as $d) $ins->execute([$d[0], $d[1], password_hash('password123', PASSWORD_DEFAULT), $d[2]]);
// Enroll the demo student in the academic course
$pdo->exec("INSERT INTO enrollments (user_id, course_id, status) VALUES (1, 1, 'active')");
echo '<p>Done. Demo accounts (password: <b>password123</b>): student@alms.test, customer@alms.test, engineer@alms.test</p>';
echo '<p><b>Delete setup.php now.</b> <a href="' . BASE_URL . '/login.php">Go to sign in</a></p>';
