<?php
require __DIR__ . '/../config.php';
require_role('student');
csrf_check();
$uid = current_user()['user_id'];

// Enroll in a free academic course
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enroll'])) {
    $cid = (int)$_POST['enroll'];
    $c = $pdo->prepare("SELECT course_id FROM courses WHERE course_id = ? AND course_type = 'academic'");
    $c->execute([$cid]);
    if ($c->fetch()) {
        $pdo->prepare('INSERT IGNORE INTO enrollments (user_id, course_id) VALUES (?,?)')->execute([$uid, $cid]);
        log_event('info', "Student enrolled in course #$cid");
        flash('You are enrolled.');
    }
    redirect('student/dashboard.php');
}

$courses = $pdo->prepare("SELECT c.* FROM enrollments e JOIN courses c ON c.course_id = e.course_id
    WHERE e.user_id = ? AND c.course_type = 'academic' ORDER BY c.title");
$courses->execute([$uid]); $courses = $courses->fetchAll();

$as = $pdo->prepare("SELECT a.*, c.title AS course_title,
    (SELECT COUNT(*) FROM submissions s WHERE s.assignment_id = a.assignment_id AND s.user_id = :u1) AS subs,
    (SELECT ev.score FROM evaluations ev JOIN submissions s ON s.submission_id = ev.submission_id
       WHERE s.assignment_id = a.assignment_id AND s.user_id = :u2 ORDER BY s.submitted_at DESC LIMIT 1) AS score,
    (SELECT ev.remarks FROM evaluations ev JOIN submissions s ON s.submission_id = ev.submission_id
       WHERE s.assignment_id = a.assignment_id AND s.user_id = :u3 ORDER BY s.submitted_at DESC LIMIT 1) AS remarks
    FROM assignments a JOIN courses c ON c.course_id = a.course_id
    JOIN enrollments e ON e.course_id = c.course_id AND e.user_id = :u4
    ORDER BY a.due_date");
$as->execute(['u1' => $uid, 'u2' => $uid, 'u3' => $uid, 'u4' => $uid]);
$assignments = $as->fetchAll();

$open = $pdo->prepare("SELECT * FROM courses WHERE course_type = 'academic'
    AND course_id NOT IN (SELECT course_id FROM enrollments WHERE user_id = ?)");
$open->execute([$uid]); $open = $open->fetchAll();

$title = 'My courses'; include __DIR__ . '/../includes/header.php';
?>
<h1>My courses</h1>
<div class="grid">
<?php foreach ($courses as $c): ?>
  <div class="card"><strong><?= e($c['title']) ?></strong>
    <p class="muted"><?= e($c['description']) ?></p>
    <details><summary>Syllabus</summary><p><?= nl2br(e(str_replace(' | ', "\n", $c['syllabus']))) ?></p></details>
  </div>
<?php endforeach; ?>
<?php if (!$courses): ?><div class="card">You are not enrolled in any course yet. Enroll below.</div><?php endif; ?>
</div>

<h2>Assignments and deadlines</h2>
<div class="scroll"><table>
<tr><th>Assignment</th><th>Course</th><th>Due</th><th>Status</th><th>Score</th><th></th></tr>
<?php foreach ($assignments as $a):
    $due = strtotime($a['due_date']); $late = $due < time();
    if ($a['subs'] > 0) { $tag = '<span class="tag ok">Submitted</span>'; }
    elseif ($late) { $tag = '<span class="tag bad">Overdue</span>'; }
    elseif ($due - time() < 3 * 86400) { $tag = '<span class="tag warn">Due soon</span>'; }
    else { $tag = '<span class="tag">Open</span>'; }
?>
<tr>
  <td><strong><?= e($a['title']) ?></strong><br><span class="muted"><?= e($a['instructions']) ?></span></td>
  <td><?= e($a['course_title']) ?></td>
  <td><?= e(format_dt($a['due_date'])) ?></td>
  <td><?= $tag ?></td>
  <td><?= $a['score'] !== null ? e($a['score']) . '<br><span class="muted">' . e($a['remarks']) . '</span>' : '-' ?></td>
  <td><a class="btn small" href="<?= BASE_URL ?>/student/submit.php?id=<?= (int)$a['assignment_id'] ?>"><?= $a['subs'] ? 'Resubmit' : 'Submit' ?></a></td>
</tr>
<?php endforeach; ?>
<?php if (!$assignments): ?><tr><td colspan="6">No assignments yet.</td></tr><?php endif; ?>
</table></div>

<?php if ($open): ?>
<h2>Available courses</h2>
<div class="grid">
<?php foreach ($open as $c): ?>
  <div class="card"><strong><?= e($c['title']) ?></strong><p class="muted"><?= e($c['description']) ?></p>
    <form method="post"><?= csrf_field() ?><button class="btn small" name="enroll" value="<?= (int)$c['course_id'] ?>">Enroll</button></form>
  </div>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
