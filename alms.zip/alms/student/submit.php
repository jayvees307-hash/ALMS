<?php
require __DIR__ . '/../config.php';
require_role('student');
csrf_check();
$uid = current_user()['user_id'];
$aid = (int)($_GET['id'] ?? 0);

$s = $pdo->prepare('SELECT a.*, c.title AS course_title FROM assignments a
    JOIN courses c ON c.course_id = a.course_id
    JOIN enrollments e ON e.course_id = c.course_id AND e.user_id = ?
    WHERE a.assignment_id = ?');
$s->execute([$uid, $aid]); $a = $s->fetch();
if (!$a) { http_response_code(404); die('Assignment not found, or you are not enrolled in its course.'); }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!flag('file_submission')) {
        $errors[] = 'File submission is switched off right now.';
    } elseif (!isset($_FILES['work']) || $_FILES['work']['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Choose a file to upload. (If it is large, check upload_max_filesize in php.ini.)';
    } else {
        $f = $_FILES['work'];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
        $okMime = ['pdf' => ['application/pdf'], 'zip' => ['application/zip', 'application/x-zip-compressed', 'application/octet-stream']];
        if (!isset($okMime[$ext]) || !in_array($mime, $okMime[$ext], true)) $errors[] = 'Only PDF or ZIP files are accepted.';
        if ($f['size'] > MAX_UPLOAD) $errors[] = 'The file is larger than 25 MB.';
        if (!$errors) {
            $stored = bin2hex(random_bytes(16)) . '.' . $ext;
            if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . $stored)) {
                $errors[] = 'The server could not save the file. Check that the uploads folder is writable.';
            } else {
                $pdo->prepare('INSERT INTO submissions (assignment_id, user_id, file_path, original_name) VALUES (?,?,?,?)')
                    ->execute([$aid, $uid, $stored, $f['name']]);
                $sid = $pdo->lastInsertId();
                $sent = @mail(current_user()['email'], 'ALMS: submission received',
                    "Hi " . current_user()['full_name'] . ",\n\nWe received your file \"" . $f['name'] . "\" for \"" . $a['title'] . "\" on " . date('M j, Y g:i A') . ".\n\nALMS");
                $pdo->prepare('UPDATE submissions SET confirmation_sent = ? WHERE submission_id = ?')->execute([$sent ? 1 : 0, $sid]);
                log_event($sent ? 'info' : 'warning', "Submission #$sid for assignment #$aid" . ($sent ? '' : ' (confirmation email not sent; check mail settings)'));
                flash('Submitted.' . ($sent ? ' A confirmation email is on its way.' : ' Your file is saved, but the confirmation email could not be sent.'));
                redirect('student/dashboard.php');
            }
        }
    }
}
$title = 'Submit assignment'; include __DIR__ . '/../includes/header.php';
?>
<h1>Submit: <?= e($a['title']) ?></h1>
<div class="card">
  <p><strong><?= e($a['course_title']) ?></strong> &middot; due <?= e(format_dt($a['due_date'])) ?></p>
  <p><?= nl2br(e($a['instructions'])) ?></p>
  <?php foreach ($errors as $er): ?><div class="flash err"><?= e($er) ?></div><?php endforeach; ?>
  <form class="stack" method="post" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <label>File (PDF or ZIP, up to 25 MB) <input type="file" name="work" accept=".pdf,.zip" required></label>
    <button class="btn">Submit file</button>
  </form>
  <p><a href="<?= BASE_URL ?>/student/dashboard.php">Back to my courses</a></p>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
