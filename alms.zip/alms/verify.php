<?php
require __DIR__ . '/config.php';
$code = trim($_GET['code'] ?? ''); $row = null;
if ($code !== '') {
    $s = $pdo->prepare('SELECT ce.certificate_code, ce.issued_at, u.full_name, c.title
        FROM certificates ce JOIN enrollments en ON en.enrollment_id = ce.enrollment_id
        JOIN users u ON u.user_id = en.user_id JOIN courses c ON c.course_id = en.course_id
        WHERE ce.certificate_code = ?');
    $s->execute([$code]); $row = $s->fetch();
}
$title = 'Verify certificate'; include __DIR__ . '/includes/header.php';
?>
<div class="card" style="max-width:560px">
  <h1>Verify a certificate</h1>
  <form class="stack" method="get">
    <label>Certificate code <input name="code" placeholder="ALMS-CERT-2026-0001" value="<?= e($code) ?>" required></label>
    <button class="btn">Check</button>
  </form>
  <?php if ($code !== ''): ?>
    <?php if ($row): ?>
      <div class="flash ok" style="margin-top:1rem"><strong>Valid.</strong> Issued to <?= e($row['full_name']) ?> for <?= e($row['title']) ?> on <?= e(format_dt($row['issued_at'])) ?>.</div>
    <?php else: ?>
      <div class="flash err" style="margin-top:1rem">No certificate matches that code.</div>
    <?php endif; ?>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
